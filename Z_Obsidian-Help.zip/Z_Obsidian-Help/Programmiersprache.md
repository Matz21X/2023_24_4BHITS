Eine **Programmiersprache** ist eine formale Sprache zur Formulierung von Datenstrukturen und Algorithmen, d. h. von Rechenvorschriften, die von einem Computer ausgeführt werden können. Sie setzen sich üblicherweise aus schrittweisen Anweisungen aus erlaubten (Text-)Mustern zusammen, der sogenannten [[Syntax]]. Ein Beispiel einer solchen Sprache ist [[Java]]

#Programming

