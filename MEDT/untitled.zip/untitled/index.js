import {exoplanetsModel} from "./exoplanetsModel.js";
import express from 'express'
import req from "express/lib/request.js";
const app = express()
const port = 3000

app.get('/', (req, res) => {
    res.send('Hello World!')
})

app.get('/exoplanets/:id', (request, response) => {
    console.log(req.params.id);
    response.status(200).send(exoplanetsModel[id]);
})

app.listen(port, () => {
    console.log(`Example app listening on port ${port}`)
})