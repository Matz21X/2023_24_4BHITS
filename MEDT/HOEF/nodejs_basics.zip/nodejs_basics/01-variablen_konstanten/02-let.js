function letProblem(){
    let myVariable = 1234;

    if(true){
        let myVariable = 4321;
    }

    console.log(myVariable);
}

letProblem();

// let verwendet block-scope