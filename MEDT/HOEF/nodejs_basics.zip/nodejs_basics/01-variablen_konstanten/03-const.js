// Konstanten mit const

const pi = 3.14159;

// erneute Zuweisungen an Konstanten sind nicht möglich
//pi = 0;

console.log(pi);

// Variablen -> let
// Konstanten -> const

// standardmäßig const
// wenn veränderungen notwendig let