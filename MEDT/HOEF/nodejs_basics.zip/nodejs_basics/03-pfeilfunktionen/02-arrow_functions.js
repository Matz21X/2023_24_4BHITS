const example = () =>{
    // ...code
    const result = 42;
    console.log(result);
}

example();





// Array mit Zahlen
const list = [4, 21, 54];

//Aufgabenstellung: Inhalte des Arrays
// verdoppeln und neue list erstelen

const ListDoubled = list.map((x) => x*2);

console.log(ListDoubled);

