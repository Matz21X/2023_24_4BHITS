// Objekt
const address = {
    firstName: 'Eduard',
    lastName: 'Müller',
    street: 'Anton Ehrenfried-Straße',
    houseNr: 10,
    zipCode: 2020,
    city: 'Hollabrunn'
};

console.log(address);

console.log(address.firstName);

