/*
    Eduard Müller
    Anton Ehrenfried-Straße 10
    2020 Hollabrunn
 */

const address = "Eduard Müller\nAnton Ehrenfried-Straße 10\n2020 Hollabrunn"
console.log(address)

const firstName = 'Eduard';
const lastname = 'Müller';
const street = 'Anton Ehrenfried-Straße';
const houseNr = 10;
const zipCode = 2020;
const city = 'Hollabrunn';

const line1 = firstName + " " + lastname +"\n";
const line2 = street + " " + houseNr +"\n";
const line3 = zipCode + " " + city;
console.log(line1 + line2 +line3)