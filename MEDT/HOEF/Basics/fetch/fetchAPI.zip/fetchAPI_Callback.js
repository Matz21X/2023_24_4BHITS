const url = 'http://localhost:3000/exoplanets';
import formatExoplanet from './exoplanetFormatter';

function fetchDataWithCallbacks() {
    fetch(url)
        .then((res) => {
            if (!res.ok) {
                throw new Error(`Error: ${res.status}`);
            }
            return res.json();
        })
        .then((data) => {
            console.log('Data successfully received:', data);
        })
        .catch((error) => {
            console.error('Error whilst recalling data:', error);
        });
}

fetchDataWithCallbacks();