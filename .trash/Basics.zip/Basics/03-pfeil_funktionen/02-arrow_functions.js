
const example = () => {
    const result = 42;
    console.log(result)
}

example();

// Array
const list = [4, 21, 54];

// Aufgabenstellung: Inhalte des Arrays
// verdoppeln und eine neue Liste erstellen

const listDoubled = list.map((x) => x * 2);


console.log(listDoubled);