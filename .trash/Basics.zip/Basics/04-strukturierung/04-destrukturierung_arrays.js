let list = [1, 2, 3];

//const num1 = list[0];
//const num2 = list[1];

const [num1, , num3] = list;

console.log(num1);
console.log(num3);
