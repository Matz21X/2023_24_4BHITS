const list1 = [1, 2, 3];
const list2 = [7, 8, 9];

const newList = [...list1, 4, 5, 6, ...list2];
console.log(newList);
