function varProblem() {
    let myVariable = 1234;

    if (true) {
        let myVariable = 4321;
    }
    console.log(myVariable)
}

varProblem()

// var verwendet block-scope