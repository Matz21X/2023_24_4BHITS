function varProblem() {
    var myVariable = 1234;

    if (true) {
        var myVariable = 4321;
    }
    console.log(myVariable)
}

varProblem()

// var verwendet functions-scope