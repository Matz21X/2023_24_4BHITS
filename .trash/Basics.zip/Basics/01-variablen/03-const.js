// Konstanten mit const
// Erneute Zuweisungen mit const nicht möglich

const pi = 3.1459

console.log(pi)

// Variablen -> let
// Konstanten -> const

// Standardmäßig const
// Wenn änderungen notwenig -> let