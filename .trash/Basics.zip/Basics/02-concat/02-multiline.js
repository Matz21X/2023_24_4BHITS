/*
    Eduard Müller
    Anton Ehrenfried-Straße 10
    2020 Hollabrunn
 */

const address = `Eduard Müller
Anton Ehrenfried-Straße 10
2020 Hollabrunn`;

console.log(address)